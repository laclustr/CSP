Notes played on the guitar directly into Audacity.
The notes are 2 octaves of the C scale, and a third octave of the root.
Note that the numbers do NOT correspond to musical notation:
C is the lowest note. The notes go CDEFGAB -> C2D2E2F2G2A2B2 -> C3
In musical notation we play from C3 to C5. i.e. C2.wav is actually middle C.
I tried to line up the attack of the notes to be the same, but each of the notes has a different amount of sustain. I fixed this in the "scale" folder, so each note has the same length.